﻿using System;
using System.Windows.Forms;

namespace Guess_the_number
{
    public partial class Form1 : Form
    {
        private int secretNumber;
        private int attempts;
        private const int maxAttempt = 7;
        public Form1()
        {
            InitializeComponent();
            StartNewGame();

        }
        private void StartNewGame()
        {
            Random rand = new Random();
            secretNumber = rand.Next(1, 101);
            attempts = 0;
            txtGuess.Clear();
            txtGuess.Focus();
            lblTemper.Text = "";
            lblResult.Text = "Я загадал число 1 до 100. Попробуй угадай!";
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtGuess.Text, out int guess))
            {
                lblResult.Text = "Пожалуйста введи целое число от 1 до 100";
                return;
            }
            attempts++;
            if (attempts > maxAttempt)
            {
                lblResult.Text = $"Попытки закончились. Загаданное число {secretNumber}";
            }

            if (guess == secretNumber)
            {
                lblResult.Text = $"Победа! Ты угадал за {attempts} попыток";
            }
            else if (guess < secretNumber)
            {
                lblResult.Text = "Больше!";
            }
            else if (guess > secretNumber)
            {
                lblResult.Text = "Меньше!";
            }
            if (Math.Abs(guess - secretNumber) < 10)
            {
                lblTemper.Text = "Горячо";
            }
            if (Math.Abs(guess - secretNumber) < 5)
            {
                lblTemper.Text = "Очень горячо";
            }
            if (Math.Abs(guess - secretNumber) > 10)
            {
                lblTemper.Text = "Холодно";
            }
            if (Math.Abs(guess - secretNumber) > 20)
            {
                lblTemper.Text = "Очень холодно";
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            StartNewGame();
        }
    }
}
